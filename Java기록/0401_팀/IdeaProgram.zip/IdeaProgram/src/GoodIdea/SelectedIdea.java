package GoodIdea;

public class SelectedIdea {
	String title = null;
	String content = null;
	String password = null;
	String writer = null;
	String[] comment = new String[10];
}
