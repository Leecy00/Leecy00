package GoodIdea;

public class Idea {
	String title = null;
	String content = null;
	String password = null;
	String writer = null;
	String[] comment = new String[10];
	boolean select = false;
	
}
